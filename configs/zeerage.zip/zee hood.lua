﻿script_key="RAGE SERVICES ATOMICDB";
shared.Ecco = {
    ['General'] = {
        ['Key'] = 'DontEditThisAtAll',
        ['Binds'] = {
            ['Aim Bot Target'] = 'C',
            ['Trigger Bot'] = 'C',
            ['Trigger Bot Target'] = 'C',
            ['Silent Aim Target'] = 'C',
            ['Inventory Sorter'] = 'B',
            ['Walk Speed'] = 'G',
        },

        ['Multi Thread'] = true, --// Disable / Enable based off FPS intake (BETA FEATURE, WILL BE REMOVED AFTER TESTING)
        ['Target Mode'] = 'Target', --// Target, Automatic
    },

    ['Aim Assist'] = {
        ['Enabled'] = true,
        ['Distance'] = 750, --// Studs

        ['Smoothness'] = 0.4,
        ['Easing Style'] = 'Circular',
        ['Easing Direction'] = 'InOut',

        ['Hit Part'] = 'Closest Part', --// Closest Point, Closest Part, HitPart Name or Table
        ['Closest Point'] = {
            ['Mode'] = 'Scaled', --// Scaled, Regular
            ['Scale'] = 0,
        },

        ['Prediction'] = {
            ['X'] = 0,
            ['Y'] = 0,
            ['Z'] = 0,

            ['Clamp Y Axis'] = { --// Use this if shooting ground, Stabilizes the Y velocity axis to prevent overshoot
                ['Enabled'] = false,
                ['Dynamic'] = false,
                ['Clamp'] = 15, --// This value will not matter if dynamic is true, as dynamic will calculate a clamp percentage automatically
            },
        },
    },

    ['Silent Aim'] = {
        ['Enabled'] = true,
        ['Distance'] = math.huge, --// Studs
        ['Client Mode'] = false, --// Will not redirect the bullet on your screen only, on other peoples screens your bullets will go towards them. Only makes you look legit from YOUR pov (DA HOOD ONLY)

        ['Target Line'] = {
            ['Enabled'] = false,
            ['Regular'] = Color3.fromRGB(255, 255, 255),
            ['In FOV'] = Color3.fromRGB(216, 103, 103),
        },

        ['Hit Part'] = 'HumanoidRootPart', --// Closest Point, Closest Part, HitPart Name or Table
        ['Closest Point'] = {
            ['Mode'] = 'Scaled', --// Scaled, Regular
            ['Scale'] = 2469.99, --// How centered the closest point should be. Higher = more centered (higher scale = less legit looking but hits more shots. vise versa)
        },

        ['Prediction'] = {
            ['X'] = 0,
            ['Y'] = 0,
            ['Z'] = 0,

            ['Clamp Y Axis'] = { --// Use this if shooting ground, Stabilizes the Y velocity axis to prevent overshoot
                ['Enabled'] = true,
                ['Dynamic'] = false,
                ['Clamp'] = 15, --// This value will not matter if dynamic is true, as dynamic will calculate a clamp percentage automatically
            },
        },

        ['FOV'] = { --// FOVs automatically stick to the target and are not followed by your mouse
            ['Enabled'] = true,
            ['Visible'] = false,
            ['Scan'] = math.huge,

            ['Mode'] = '2D', --// 3D, 2D

            ['2D'] = {
                ['Prediction'] = false,
                ['Stick'] = true,
                ['X'] = 2500,
                ['Y'] = 2500,
            },
            ['3D'] = {
                ['Prediction'] = false,
                ['X'] = 0,
                ['Y'] = 0,
                ['Z'] = 0,
            },
        },
    },

    ['Trigger Bot'] = {
        ['Enabled'] = true,
        ['Distance'] = 400, --// Studs

        ['Cooldown'] = 0,

        ['Prediction'] = {
            ['X'] = 0,
            ['Y'] = 0,
            ['Z'] = 0,
        },

        ['Activation'] = {
            ['Mode'] = 'Keybind', --// Keybind, Mouse
            ['Type'] = 'Toggle', --// Hold, Toggle
        },

        ['FOV'] = { --// FOVs automatically stick to the target and are not followed by your mouse
            ['Enabled'] = true,
            ['Visible'] = false,
            ['Scan'] = math.huge, --// Degrees

            ['2D'] = {
                ['Prediction'] = false,
                ['Stick'] = false,
                ['X'] = 2500,
                ['Y'] = 2500,
            },
        },
    },

    ['Player Modifications'] = {
        ['Anti Fall'] = true,

        ['Speed'] = {
            ['Enabled'] =true,

            ['Low Health'] = {
                ['Value'] = 4,
            },

            ['Reloading'] = {
                ['Value'] = 4,
            },

            ['Default'] = {
                ['Value'] = 4,
            },
        },
    },

    ['Weapon Modifications'] = { --// You can add any weapon with its full name and the value for it. e.g: ['[LMG]'] = { ['Value'] = true } etc. THESE ARE FOR DA HOOD ONLY. NO COPIES
        ['Spread Changer'] = {
            ['Enabled'] = true,

            ['[Double-Barrel SG]'] = {
                ['Value'] = 0.66, --// 0 = No Spread, 1 = Regular spread
            },

            ['[TacticalShotgun]'] = {
                ['Value'] = 0.66, --// 0 = No Spread, 1 = Regular spread
            },

            ['[Shotgun]'] = {
                ['Value'] = 0.66, --// 0 = No Spread, 1 = Regular spread
            },
        },

        ['Double Tap'] = {
            ['Enabled'] = false,

            ['[Revolver]'] = {
                ['Value'] = true,
            },

            ['[Silencer]'] = {
                ['Value'] = true,
            },

            ['[Glock]'] = {
                ['Value'] = true,
            },
        },

        ['Delay Changer'] = { --// Below are the default delay values for weapons, going too low on some may cause fake bullets to spawn in on your client only.
            ['Enabled'] = false,

            ['[Double-Barrel SG]'] = {
                ['Value'] = 0.0595,
            },

            ['[TacticalShotgun]'] = {
                ['Value'] = 0.0095,
            },

            ['[Revolver]'] = {
                ['Value'] = 0.0095,
            },
        },
    },

    ['Game Utilities'] = {
        ['Inventory Sorter'] = {
            ['Enabled'] = true,
            ['Order'] = {
                '[Revolver]',
                '[Double-Barrel SG]',
                '[TacticalShotgun]',
                '[Knife]',
            },
        },
    },
}
loadstring(
    game:HttpGet(
        'https://api.luarmor.net/files/v3/loaders/b1811d127e413f6969f0005bb55142ae.lua'
    )
)()
